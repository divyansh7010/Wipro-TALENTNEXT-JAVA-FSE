package abstraction_packages_exception_handling.assignments.interfaces.music;

public interface Playable {
    void play();
}
