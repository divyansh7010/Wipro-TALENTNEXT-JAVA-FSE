package abstraction_packages_exception_handling.assignments.packages.solution2;
// package com.wipro.automobile.ship ; 
public class Compartment {
    int height ; 
    int width ; 
    int breadth ; 
}
